
public class Ellipse extends Shape{

	public void draw(){
		System.out.println("Drawing Ellipse with color="+getColor());
	}

}
