/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercise1;

/**Class to Show the Test
* @author Fabio Alexandre Ciconi -- 300930909
* @version 1
* @since Release 10/02/2017
*/
public class DriverTest {


   /**
    * @param args the command line arguments
    */
   public static void main(String[] args) 
   {
      Questions nome = new Questions();
      nome.doTest();
   }
}

